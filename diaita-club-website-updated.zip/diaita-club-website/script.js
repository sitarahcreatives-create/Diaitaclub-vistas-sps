(() => {
  "use strict";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  // Current year in footer
  const year = $("#currentYear");
  if (year) year.textContent = new Date().getFullYear();

  // Mobile navigation
  const menuToggle = $("#menuToggle");
  const nav = $("#primaryNav");
  const closeMenu = () => {
    nav?.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
    menuToggle?.setAttribute("aria-label", "Open navigation menu");
  };
  menuToggle?.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
  });
  $$(".primary-nav a").forEach(link => link.addEventListener("click", closeMenu));

  // Scroll reveal, with a graceful fallback for older browsers
  const revealItems = $$(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add("visible"));
  }

  // Active navigation based on visible sections
  const sectionLinks = $$(".nav-link");
  const sections = sectionLinks.map(link => $(link.getAttribute("href"))).filter(Boolean);
  if ("IntersectionObserver" in window) {
    const activeObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        sectionLinks.forEach(link => link.classList.toggle("active", link.getAttribute("href") === `#${entry.target.id}`));
      });
    }, { rootMargin: "-35% 0px -55% 0px" });
    sections.forEach(section => activeObserver.observe(section));
  }

  // Search overlay
  const searchOverlay = $("#searchOverlay");
  const searchInput = $("#siteSearch");
  const searchResults = $("#searchResults");
  const searchOpen = $("#searchOpen");
  const searchClose = $("#searchClose");
  let lastFocused = null;
  const searchableSections = [
    { title: "School of Pharmaceutical Sciences", description: "Department background, pharmacy education, research, and VISTAS.", href: "#school", keywords: "school department VISTAS pharmacy research 1992 2008" },
    { title: "About DIAITA CLUB", description: "Our philosophy, purpose, and holistic wellness approach.", href: "#about", keywords: "about club philosophy wellness diet lifestyle" },
    { title: "DIAITA Philosophy", description: "A wider view of wellness and mindful choices.", href: "#philosophy", keywords: "holistic mind body culture emotional physical" },
    { title: "Holistic Wellness", description: "Encouraging balanced and mindful choices.", href: "#activities", keywords: "health wellness awareness" },
    { title: "Pharmacy Education", description: "Connecting pharmaceutical sciences with health awareness.", href: "#activities", keywords: "pharmacy education learning" },
    { title: "Sports & Fitness", description: "Movement, teamwork, and resilience.", href: "#activities", keywords: "sports fitness movement" },
    { title: "Workshops & Outreach", description: "Community participation and shared learning.", href: "#activities", keywords: "workshop outreach community" },
    { title: "Upcoming Events", description: "Confirmed event details will be announced here.", href: "#events", keywords: "events calendar announcements" },
    { title: "Our Team", description: "Meet the DIAITA CLUB student team.", href: "#team", keywords: "team students members coordinators" },
    { title: "Staff & Coordinators", description: "Faculty guidance and student coordinators.", href: "#staff", keywords: "staff faculty coordinator designation" },
    { title: "Achievements", description: "Faculty, coordinators, and achievement highlights.", href: "#achievements", keywords: "achievements faculty certificates staff" },
    { title: "Membership", description: "Register your interest in joining DIAITA CLUB.", href: "#membership", keywords: "membership join register application" },
    { title: "Contact Us", description: "Email the club or find its Instagram profile.", href: "#contact", keywords: "contact email instagram social" }
  ];
  function openSearch() {
    lastFocused = document.activeElement;
    searchOverlay.classList.add("open");
    searchOverlay.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    window.setTimeout(() => searchInput.focus(), 60);
  }
  function closeSearch() {
    searchOverlay.classList.remove("open");
    searchOverlay.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    if (lastFocused && typeof lastFocused.focus === "function") lastFocused.focus();
  }
  function renderSearch(query) {
    const term = query.trim().toLowerCase();
    if (!term) {
      searchResults.innerHTML = '<p class="search-hint">Try “wellness”, “activities”, “team”, or “membership”.</p>';
      return;
    }
    const matches = searchableSections.filter(item => `${item.title} ${item.description} ${item.keywords}`.toLowerCase().includes(term));
    if (!matches.length) {
      searchResults.innerHTML = '<p class="no-results">No results found. Try another keyword.</p>';
      return;
    }
    searchResults.innerHTML = matches.map(item => `<a class="search-result" href="${item.href}"><strong>${item.title}</strong><span>${item.description}</span></a>`).join("");
    $$(".search-result", searchResults).forEach(link => link.addEventListener("click", closeSearch));
  }
  searchOpen?.addEventListener("click", openSearch);
  searchClose?.addEventListener("click", closeSearch);
  searchInput?.addEventListener("input", event => renderSearch(event.target.value));
  searchOverlay?.addEventListener("click", event => { if (event.target === searchOverlay) closeSearch(); });

  // Membership application: submit to the supplied Google Apps Script web app.
  // no-cors intentionally prevents a CORS read; the page therefore cannot verify
  // the server's response body. The confirmation below is transparent about this.
  const MEMBERSHIP_ENDPOINT = "https://script.google.com/macros/s/AKfycbzQwgwgFgmyNkmsbK1BJ4BmuA7F8TgKrg2mmioGIPX8WqeVKxRYM1K29Db1zoJjpLNK/exec";
  const membershipModal = $("#membershipModal");
  const membershipOpen = $("#membershipOpen");
  const membershipClose = $("#membershipClose");
  const membershipForm = $("#membershipForm");
  const formError = $("#formError");
  const formSuccess = $("#formSuccess");
  const successClose = $("#successClose");
  const formSubmit = $("#membershipSubmit");

  function openMembership() {
    lastFocused = document.activeElement;
    membershipModal.classList.add("open");
    membershipModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    window.setTimeout(() => $('input[name="fullName"]', membershipForm)?.focus(), 70);
  }
  function closeMembership() {
    membershipModal.classList.remove("open");
    membershipModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    if (lastFocused && typeof lastFocused.focus === "function") lastFocused.focus();
  }
  membershipOpen?.addEventListener("click", openMembership);
  membershipClose?.addEventListener("click", closeMembership);
  successClose?.addEventListener("click", closeMembership);
  membershipModal?.addEventListener("click", event => { if (event.target === membershipModal) closeMembership(); });

  membershipForm?.addEventListener("reset", () => {
    if (formError) { formError.hidden = true; formError.textContent = ""; }
    if (formSuccess) formSuccess.hidden = true;
    if (membershipForm) membershipForm.hidden = false;
    if (formSubmit) { formSubmit.disabled = false; formSubmit.innerHTML = 'Submit application <span aria-hidden="true">→</span>'; }
  });

  membershipForm?.addEventListener("submit", async event => {
    event.preventDefault();
    if (formError) { formError.hidden = true; formError.textContent = ""; }
    if (!membershipForm.checkValidity()) {
      membershipForm.reportValidity();
      if (formError) {
        formError.textContent = "Please complete all required fields with valid information and accept the privacy consent.";
        formError.hidden = false;
      }
      return;
    }

    const values = Object.fromEntries(new FormData(membershipForm).entries());
    const payload = {
      formType: "membership",
      timestamp: new Date().toISOString(),
      fullName: String(values.fullName || "").trim(),
      name: String(values.fullName || "").trim(),
      courseYear: String(values.courseYear || "").trim(),
      course: String(values.courseYear || "").trim(),
      department: String(values.department || "").trim(),
      email: String(values.email || "").trim(),
      phone: String(values.phone || "").trim(),
      interest: String(values.interest || "").trim(),
      preferredActivities: String(values.preferredActivities || "").trim(),
      motivation: String(values.motivation || "").trim(),
      consent: values.consent === "Yes" ? "Yes" : "No"
    };

    if (formSubmit) { formSubmit.disabled = true; formSubmit.textContent = "Sending application…"; }
    try {
      // URLSearchParams + application/x-www-form-urlencoded is a simple request
      // format accepted by typical Apps Script doPost(e) handlers using e.parameter.
      // no-cors means we cannot inspect the backend's HTTP status/body.
      await fetch(MEMBERSHIP_ENDPOINT, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
        body: new URLSearchParams(payload).toString()
      });
      membershipForm.hidden = true;
      if (formSuccess) formSuccess.hidden = false;
      const successMessage = $("#formSuccessMessage");
      if (successMessage) {
        successMessage.textContent = "Your browser sent the application request to the Google Apps Script endpoint. Because the endpoint does not expose a readable response to this page, we cannot independently confirm that it was recorded. If you need confirmation, email diaitaclub2025@gmail.com.";
      }
    } catch (error) {
      if (formError) {
        formError.textContent = "We couldn't send the application request. Please check your internet connection and try again, or email diaitaclub2025@gmail.com.";
        formError.hidden = false;
      }
      if (formSubmit) { formSubmit.disabled = false; formSubmit.innerHTML = 'Try again <span aria-hidden="true">→</span>'; }
    }
  });

  // Contact form opens a pre-filled email; it does not claim to send/store messages.
  const contactForm = $("#contactForm");
  contactForm?.addEventListener("submit", event => {
    event.preventDefault();
    if (!contactForm.checkValidity()) { contactForm.reportValidity(); return; }
    const values = Object.fromEntries(new FormData(contactForm).entries());
    const subject = encodeURIComponent(String(values.contactSubject || "").trim());
    const body = encodeURIComponent(
      `Name: ${String(values.contactName || "").trim()}\n` +
      `Reply email: ${String(values.contactEmail || "").trim()}\n\n` +
      `${String(values.contactMessage || "").trim()}`
    );
    window.location.href = `mailto:diaitaclub2025@gmail.com?subject=${subject}&body=${body}`;
  });

  // Activity category filters
  const activityFilters = $$(".filter-chip");
  const activityCards = $$(".activity-card[data-category]");
  activityFilters.forEach(button => {
    button.addEventListener("click", () => {
      const selected = button.dataset.filter || "all";
      activityFilters.forEach(item => {
        const active = item === button;
        item.classList.toggle("active", active);
        item.setAttribute("aria-pressed", String(active));
      });
      activityCards.forEach(card => {
        const visible = selected === "all" || card.dataset.category === selected;
        card.hidden = !visible;
      });
    });
  });

  // Escape closes open overlays and mobile menu
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      if (searchOverlay?.classList.contains("open")) closeSearch();
      if (membershipModal?.classList.contains("open")) closeMembership();
      closeMenu();
    }
  });

  // Inform users that demo sections contain placeholders, without pretending to submit data.
  const toast = $("#toast");
  let toastTimer;
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2600);
  }
  $$(".round-arrow").forEach(link => link.addEventListener("click", () => {
    showToast("Membership interest form opens from the membership section.");
  }));
})();
