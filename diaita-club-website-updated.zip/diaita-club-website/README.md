# DIAITA CLUB website

A responsive, multi-section single-page website for **DIAITA CLUB — School of Pharmaceutical Sciences, VISTAS**, established in 2025.

## Included files

- `index.html` — all website content, membership form, contact form, search overlay, and dialogs.
- `styles.css` — responsive styling, motion, cards, and layout.
- `script.js` — mobile navigation, section reveals, search, membership submission, and contact email drafting.
- `assets/logo.png` — the supplied DIAITA CLUB logo, included locally so the main logo does not depend on a remote image host.

## Brand and official contact details

- Club: DIAITA CLUB
- Institution: School of Pharmaceutical Sciences, VISTAS
- Established: 2025
- Tagline: “The Apothecary Together With the Manner of Living”
- Email: `diaitaclub2025@gmail.com`
- Instagram: [@diaitaclub.vistas](https://www.instagram.com/diaitaclub.vistas/)
- Membership endpoint: the Google Apps Script URL supplied by the club is configured in `script.js`.

## Preview locally

1. Extract the ZIP.
2. Open `index.html` in a modern browser, or open the folder in VS Code and run it with Live Server.
3. The logo and inline SVG icons are local/included. Activity-card photographs use remote Unsplash image URLs and therefore require an internet connection. If you want the website fully offline, download approved photographs into `assets/` and replace the CSS `background-image` URLs in `styles.css`.

## Membership endpoint integration

`script.js` posts URL-encoded fields to the provided Apps Script `/exec` URL. The request includes `formType`, `timestamp`, `fullName` (and alias `name`), `courseYear` (and alias `course`), `department`, `email`, `phone`, `interest`, `preferredActivities`, `motivation`, and `consent`.

The browser request uses `mode: "no-cors"` to avoid a browser CORS read restriction. This means the page **cannot inspect the backend response or verify that the application was saved**. It only tells the applicant that the request was sent by the browser and clearly says that server-side receipt is not independently confirmed. The Google Apps Script deployment must be accessible to intended applicants and its `doPost(e)` handler must read these URL-encoded values from `e.parameter` and save them to the intended destination (for example, a Google Sheet). The endpoint's implementation could not be inspected from this environment, so test a real submission in the destination spreadsheet before publishing.

For the backend, check that:
- the web app is deployed as `/exec`;
- access permissions allow intended students to submit;
- `doPost(e)` accepts the listed field names;
- the destination sheet records applications without exposing student data publicly;
- duplicate submissions and spam are considered;
- the privacy notice matches the club's actual retention and access practices.

Do not put private API keys or credentials in this public website.

## Contact form

The contact form validates fields and opens a pre-filled email draft addressed to `diaitaclub2025@gmail.com`. It does not store messages on the website.

## Content maintenance

- Edit text directly in `index.html`.
- Replace `Team Member`, `Faculty name to be added`, and coordinator placeholders only with approved details.
- Add confirmed events and achievements only after dates/details are verified. No event dates, staff names, or achievements have been invented.
- Keep `assets/logo.png` as the official logo, or replace it only with a club-approved logo file.
